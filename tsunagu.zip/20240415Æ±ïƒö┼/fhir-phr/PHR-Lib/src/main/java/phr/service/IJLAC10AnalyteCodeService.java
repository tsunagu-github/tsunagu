package phr.service;


/**
 * 
 * @author kisvdi017
 *
 */
public interface IJLAC10AnalyteCodeService {
}
