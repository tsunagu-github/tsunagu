package phr.service;


/**
 * 
 * @author kisvdi017
 *
 */
public interface IJLAC11AnalyteCodeService {
}
